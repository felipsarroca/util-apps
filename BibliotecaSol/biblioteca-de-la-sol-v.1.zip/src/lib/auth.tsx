import { createContext, useContext, useState, useEffect } from 'react';

type User = {
  id: string;
  email: string;
  nom: string;
  cognoms: string;
  rol: 'admin' | 'editor' | 'lector';
};

type AuthContextType = {
  user: User | null;
  login: (email: string) => void;
  logout: () => void;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('biblioteca_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const login = (email: string) => {
    if (!email.endsWith('@ramonpont.cat')) {
      alert('Només es poden registrar usuaris amb correu institucional acabat en @ramonpont.cat.');
      return;
    }
    const isEditor = email.startsWith('editor'); // for demo purposes
    const newUser: User = {
      id: Math.random().toString(36).substring(7),
      email,
      nom: 'Usuari',
      cognoms: 'Prova',
      rol: isEditor ? 'editor' : 'lector'
    };
    setUser(newUser);
    localStorage.setItem('biblioteca_user', JSON.stringify(newUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('biblioteca_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

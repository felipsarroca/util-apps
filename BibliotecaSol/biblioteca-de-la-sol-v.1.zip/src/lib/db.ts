export type Llibre = {
  id: string;
  titol: string;
  autor: string;
  editorial: string;
  isbn: string;
  any_publicacio: string;
  llengua: string;
  nivell_recomanat: string;
  tematica: string;
  genere: string;
  resum: string;
  imatge_portada: string;
  actiu: boolean;
};

export type Exemplar = {
  id: string;
  llibre_id: string;
  codi_exemplar: string;
  ubicacio: string;
  estat: string;
  disponible: boolean;
  descatalogat: boolean;
};

// Initial mock data
const INITIAL_LLIBRES: Llibre[] = [
  {
    id: '1',
    titol: 'El petit príncep',
    autor: 'Antoine de Saint-Exupéry',
    editorial: 'Salamandra',
    isbn: '978-84-9838-149-8',
    any_publicacio: '1943',
    llengua: 'Català',
    nivell_recomanat: 'Cicle Mitjà',
    tematica: 'Ficció',
    genere: 'Novel·la curta',
    resum: 'Un llibre clàssic que parla sobre lamistat, lamor i lassumpció de responsabilitats.',
    imatge_portada: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?q=80&w=600&auto=format&fit=crop', // generic book cover
    actiu: true
  },
  {
    id: '2',
    titol: 'Harry Potter i la pedra filosofal',
    autor: 'J.K. Rowling',
    editorial: 'Empúries',
    isbn: '978-84-7596-616-5',
    any_publicacio: '1997',
    llengua: 'Català',
    nivell_recomanat: 'Cicle Superior',
    tematica: 'Màgia',
    genere: 'Fantasia',
    resum: 'El primer llibre de la famosa saga del nen mag.',
    imatge_portada: 'https://images.unsplash.com/photo-1626618012641-bfbca5a31239?q=80&w=600&auto=format&fit=crop',
    actiu: true
  }
];

export const db = {
  getLlibres: (): Llibre[] => {
    const data = localStorage.getItem('biblioteca_llibres');
    return data ? JSON.parse(data) : INITIAL_LLIBRES;
  },
  saveLlibre: (llibre: Llibre) => {
    const llibres = db.getLlibres();
    const index = llibres.findIndex(l => l.id === llibre.id);
    if (index >= 0) llibres[index] = llibre;
    else llibres.push(llibre);
    localStorage.setItem('biblioteca_llibres', JSON.stringify(llibres));
  },
  deleteLlibre: (id: string) => {
    const llibres = db.getLlibres().filter(l => l.id !== id);
    localStorage.setItem('biblioteca_llibres', JSON.stringify(llibres));
  }
};

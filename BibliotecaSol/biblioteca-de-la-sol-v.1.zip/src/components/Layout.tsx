import Header from './Header';
import { Outlet } from 'react-router-dom';

export default function Layout() {
  return (
    <div className="min-h-screen bg-[#FDFBF7] flex flex-col font-sans">
      <Header />
      <main className="flex-1 w-full max-w-7xl mx-auto px-6 py-8">
        <Outlet />
      </main>
      <footer className="py-8 text-center bg-white border-t border-gray-200">
        <p className="text-sm font-medium text-gray-600 mb-1">
          <a href="https://ja.cat/felipsarroca" target="_blank" rel="noopener noreferrer" className="hover:text-amber-600 transition-colors">Felip Sarroca</a> &mdash; Biblioteca de la Sol v1.0
        </p>
        <p className="text-xs text-gray-400">
          Codi: AGPLv3 · Continguts: CC BY-NC-SA 4.0 · © 2026 · Suggeriments i errors
        </p>
      </footer>
    </div>
  );
}

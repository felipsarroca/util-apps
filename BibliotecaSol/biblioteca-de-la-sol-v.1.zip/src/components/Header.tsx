import { Sun } from 'lucide-react';
import { useAuth } from '../lib/auth';
import { Link, useNavigate } from 'react-router-dom';

export default function Header() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="bg-white border-b border-[#e2e8f0] sticky top-0 z-10 px-6 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#FFD166] rounded-full flex items-center justify-center shadow-sm">
            <Sun className="w-6 h-6 text-[#1E1E24]" strokeWidth={2.5} />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900 leading-tight">Biblioteca de la Sol</h1>
            <p className="text-xs font-medium text-gray-500 tracking-wide uppercase">Escola Ramon Pont</p>
          </div>
        </Link>

        {user && (
          <div className="flex items-center gap-6">
            <nav className="flex items-center gap-4 text-sm font-medium text-gray-600">
              <Link to="/" className="hover:text-gray-900 transition-colors">Catàleg</Link>
              {(user.rol === 'editor' || user.rol === 'admin') && (
                <Link to="/editor" className="hover:text-gray-900 transition-colors">Editor</Link>
              )}
            </nav>
            <div className="flex items-center gap-4 pl-6 border-l border-gray-200">
              <div className="text-sm">
                <p className="font-medium text-gray-900">{user.nom} {user.cognoms}</p>
                <p className="text-xs text-gray-500">{user.rol}</p>
              </div>
              <button 
                onClick={handleLogout}
                className="text-sm px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-full transition-colors font-medium"
              >
                Sortir
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}

import { useState } from 'react';
import { useAuth } from '../lib/auth';
import { Sun } from 'lucide-react';

export default function Login() {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.endsWith('@ramonpont.cat')) {
      setError('Només es poden registrar usuaris amb correu institucional acabat en @ramonpont.cat.');
      return;
    }
    setError('');
    login(email);
  };

  return (
    <div className="max-w-md mx-auto mt-20 bg-white p-8 rounded-[32px] shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-gray-100 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-[#FFD166] rounded-full blur-[80px] opacity-40 -mr-10 -mt-10 pointer-events-none" />
      
      <div className="w-16 h-16 bg-[#FFD166] rounded-full flex items-center justify-center shadow-sm mb-8 mx-auto relative z-10">
        <Sun className="w-8 h-8 text-[#1E1E24]" strokeWidth={2.5} />
      </div>

      <div className="text-center mb-8 relative z-10">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Benvinguts a la Biblioteca</h2>
        <p className="text-gray-500 text-sm">Inicia sessió amb el teu correu de l'escola</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5 relative z-10">
        <div>
          <label htmlFor="email" className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-2">
            Correu institucional
          </label>
          <input
            id="email"
            type="email"
            placeholder="nom@ramonpont.cat"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-4 py-3 rounded-2xl border border-gray-200 bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#FFD166] focus:border-transparent transition-all placeholder:text-gray-400 font-medium"
            required
          />
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-100 text-red-600 text-sm font-medium">
            {error}
          </div>
        )}

        <button
          type="submit"
          className="w-full bg-[#1E1E24] hover:bg-black text-white font-medium py-3.5 rounded-2xl transition-colors shadow-sm"
        >
          Entrar al Catàleg
        </button>
      </form>
    </div>
  );
}

import { useState } from 'react';
import { db, Llibre, Exemplar } from '../lib/db';
import { useAuth } from '../lib/auth';
import { useNavigate } from 'react-router-dom';
import { PlusCircle, Save, BookCopy } from 'lucide-react';

export default function Editor() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const llibres = db.getLlibres();
  
  const [activeTab, setActiveTab] = useState<'llibre' | 'exemplar'>('llibre');

  if (!user || (user.rol !== 'editor' && user.rol !== 'admin')) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Accés denegat</h2>
        <p className="text-gray-500">Només els editors poden accedir a aquesta pàgina.</p>
      </div>
    );
  }

  // Llibre State
  const [titol, setTitol] = useState('');
  const [autor, setAutor] = useState('');
  const [isbn, setIsbn] = useState('');
  const [anyP, setAnyP] = useState('');
  const [editorial, setEditorial] = useState('');
  const [tematica, setTematica] = useState('Ficció');
  const [nivell, setNivell] = useState('Cicle Inicial');

  const handleLlibreSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nouLlibre: Llibre = {
      id: Math.random().toString(36).substring(7),
      titol,
      autor,
      isbn,
      editorial,
      any_publicacio: anyP,
      llengua: 'Català',
      nivell_recomanat: nivell,
      tematica,
      genere: 'Novel·la',
      resum: '',
      imatge_portada: '',
      actiu: true
    };
    db.saveLlibre(nouLlibre);
    alert('Llibre afegit correctament!');
    setTitol('');
    setAutor('');
    setIsbn('');
    setAnyP('');
  };

  // Exemplar State
  const [llibreId, setLlibreId] = useState('');
  const [ubicacio, setUbicacio] = useState('Biblioteca central');
  const [observacions, setObservacions] = useState('');

  const handleExemplarSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!llibreId) {
      alert('Tria un llibre primer');
      return;
    }
    const codi = `RP-${Math.floor(100000 + Math.random() * 900000)}`;
    const nouExemplar: Exemplar = {
      id: Math.random().toString(36).substring(7),
      llibre_id: llibreId,
      codi_exemplar: codi,
      ubicacio,
      estat: 'Nou',
      disponible: true,
      descatalogat: false
    };
    
    // In a real DB we'd save the exemplar. Here we will just log it or save to local storage.
    const exs = JSON.parse(localStorage.getItem('biblioteca_exemplars') || '[]');
    exs.push(nouExemplar);
    localStorage.setItem('biblioteca_exemplars', JSON.stringify(exs));

    alert(`Exemplar creat correctament amb el codi únic: ${codi}`);
    setLlibreId('');
    setObservacions('');
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-in fade-in duration-500">
      
      <div className="flex items-end justify-between border-b border-gray-200 pb-6">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2 font-serif">Editor del Catàleg</h2>
          <p className="text-gray-500 text-sm">Afegeix, edita o descataloga llibres i exemplars.</p>
        </div>
      </div>

      <div className="flex gap-4 mb-6">
        <button 
          onClick={() => setActiveTab('llibre')}
          className={`px-5 py-2.5 rounded-2xl text-sm font-medium transition-colors flex items-center gap-2 ${
            activeTab === 'llibre' ? 'bg-[#1E1E24] text-white shadow-sm' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
          }`}
        >
          <PlusCircle className="w-4 h-4" /> Nou Llibre
        </button>
        <button 
          onClick={() => setActiveTab('exemplar')}
          className={`px-5 py-2.5 rounded-2xl text-sm font-medium transition-colors flex items-center gap-2 ${
            activeTab === 'exemplar' ? 'bg-[#1E1E24] text-white shadow-sm' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
          }`}
        >
          <BookCopy className="w-4 h-4" /> Nou Exemplar
        </button>
      </div>

      {activeTab === 'llibre' && (
        <div className="bg-white rounded-3xl p-8 shadow-[0_4px_20px_rgb(0,0,0,0.03)] border border-gray-100">
          <h3 className="text-lg font-bold text-gray-900 mb-6">Informació del Llibre</h3>
          
          <form onSubmit={handleLlibreSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide">Títol del llibre</label>
                <input type="text" value={titol} onChange={e=>setTitol(e.target.value)} required 
                  className="w-full px-4 py-3 rounded-2xl border border-gray-200 bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#FFD166] focus:border-transparent transition-all font-medium text-gray-900" 
                />
              </div>
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide">Autor/a</label>
                <input type="text" value={autor} onChange={e=>setAutor(e.target.value)} required 
                  className="w-full px-4 py-3 rounded-2xl border border-gray-200 bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#FFD166] focus:border-transparent transition-all font-medium text-gray-900" 
                />
              </div>
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide">Editorial</label>
                <input type="text" value={editorial} onChange={e=>setEditorial(e.target.value)} required 
                  className="w-full px-4 py-3 rounded-2xl border border-gray-200 bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#FFD166] focus:border-transparent transition-all font-medium text-gray-900" 
                />
              </div>
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide">ISBN</label>
                <input type="text" value={isbn} onChange={e=>setIsbn(e.target.value)} 
                  className="w-full px-4 py-3 rounded-2xl border border-gray-200 bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#FFD166] focus:border-transparent transition-all font-medium text-gray-900" 
                />
              </div>
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide">Any de publicació</label>
                <input type="text" value={anyP} onChange={e=>setAnyP(e.target.value)} 
                  className="w-full px-4 py-3 rounded-2xl border border-gray-200 bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#FFD166] focus:border-transparent transition-all font-medium text-gray-900" 
                />
              </div>
              
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide">Temàtica</label>
                <select value={tematica} onChange={e=>setTematica(e.target.value)} 
                  className="w-full px-4 py-3 rounded-2xl border border-gray-200 bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#FFD166] focus:border-transparent transition-all font-medium text-gray-900"
                >
                  <option value="Ficció">Ficció</option>
                  <option value="Coneixements">Coneixements</option>
                  <option value="Còmic">Còmic</option>
                  <option value="Àlbum il·lustrat">Àlbum il·lustrat</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide">Nivell</label>
                <select value={nivell} onChange={e=>setNivell(e.target.value)} 
                  className="w-full px-4 py-3 rounded-2xl border border-gray-200 bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#FFD166] focus:border-transparent transition-all font-medium text-gray-900"
                >
                  <option value="Educació Infantil">Educació Infantil</option>
                  <option value="Cicle Inicial">Cicle Inicial</option>
                  <option value="Cicle Mitjà">Cicle Mitjà</option>
                  <option value="Cicle Superior">Cicle Superior</option>
                  <option value="Mestres">Mestres</option>
                </select>
              </div>
            </div>
            
            <div className="pt-4 flex justify-end">
              <button type="submit" className="flex items-center gap-2 bg-[#5A5A40] hover:bg-[#43432f] text-white px-6 py-3 rounded-2xl text-sm font-bold transition-colors shadow-sm">
                <Save className="w-4 h-4" />
                Desar Llibre
              </button>
            </div>
          </form>
        </div>
      )}

      {activeTab === 'exemplar' && (
        <div className="bg-white rounded-3xl p-8 shadow-[0_4px_20px_rgb(0,0,0,0.03)] border border-gray-100">
          <h3 className="text-lg font-bold text-gray-900 mb-6">Nou Exemplar</h3>
          
          <form onSubmit={handleExemplarSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide">Llibre</label>
                <select value={llibreId} onChange={e=>setLlibreId(e.target.value)} required 
                  className="w-full px-4 py-3 rounded-2xl border border-gray-200 bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#FFD166] focus:border-transparent transition-all font-medium text-gray-900"
                >
                  <option value="">-- Selecciona un llibre --</option>
                  {llibres.map(l => (
                    <option key={l.id} value={l.id}>{l.titol} ({l.autor})</option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide">Ubicació</label>
                <input type="text" value={ubicacio} onChange={e=>setUbicacio(e.target.value)} required 
                  className="w-full px-4 py-3 rounded-2xl border border-gray-200 bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#FFD166] focus:border-transparent transition-all font-medium text-gray-900" 
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide">Observacions (opcional)</label>
                <textarea value={observacions} onChange={e=>setObservacions(e.target.value)} rows={3}
                  className="w-full px-4 py-3 rounded-2xl border border-gray-200 bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#FFD166] focus:border-transparent transition-all font-medium text-gray-900" 
                />
              </div>
            </div>
            
            <div className="pt-4 flex justify-end">
              <button type="submit" className="flex items-center gap-2 bg-[#5A5A40] hover:bg-[#43432f] text-white px-6 py-3 rounded-2xl text-sm font-bold transition-colors shadow-sm">
                <Save className="w-4 h-4" />
                Registrar Exemplar
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
}

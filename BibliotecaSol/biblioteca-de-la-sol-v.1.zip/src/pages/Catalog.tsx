import { useState, useMemo } from 'react';
import { Search, Filter, BookOpen } from 'lucide-react';
import { db, Llibre } from '../lib/db';

export default function Catalog() {
  const llibres = db.getLlibres();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTopic, setSelectedTopic] = useState<string>('Tots');

  const topics = ['Tots', ...Array.from(new Set(llibres.map(l => l.tematica)))];

  const filteredLlibres = useMemo(() => {
    return llibres.filter(llibre => {
      const matchesSearch = llibre.titol.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           llibre.autor.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesTopic = selectedTopic === 'Tots' || llibre.tematica === selectedTopic;
      return matchesSearch && matchesTopic && llibre.actiu;
    });
  }, [llibres, searchTerm, selectedTopic]);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Descobreix llocs nous</h2>
          <p className="text-gray-500">Explora el nostre catàleg per trobar la teva propera lectura</p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input 
              type="text" 
              placeholder="Cerca un títol o autor..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 pr-4 py-2.5 rounded-2xl border border-gray-200 bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-[#FFD166] min-w-[260px] text-sm"
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0 hide-scrollbar">
            {topics.map(topic => (
              <button
                key={topic}
                onClick={() => setSelectedTopic(topic)}
                className={`flex-shrink-0 px-4 py-2 rounded-2xl text-sm font-medium transition-colors ${
                  selectedTopic === topic 
                    ? 'bg-[#1E1E24] text-white' 
                    : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50 hover:text-gray-900 shadow-sm'
                }`}
              >
                {topic}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredLlibres.map((llibre) => (
          <div key={llibre.id} className="bg-white rounded-3xl p-5 shadow-[0_4px_20px_rgb(0,0,0,0.03)] border border-gray-100 hover:shadow-[0_8px_30px_rgb(0,0,0,0.08)] transition-all group cursor-pointer flex flex-col h-full">
            <div className="aspect-[3/4] w-full rounded-2xl overflow-hidden bg-gray-100 mb-4 relative">
              {llibre.imatge_portada ? (
                <img src={llibre.imatge_portada} alt={llibre.titol} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-gray-300">
                  <BookOpen className="w-12 h-12" />
                </div>
              )}
              <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm px-2.5 py-1 rounded-lg text-[10px] font-bold tracking-wider uppercase text-gray-700 shadow-sm">
                {llibre.nivell_recomanat}
              </div>
            </div>
            
            <div className="flex-1 flex flex-col">
              <h3 className="font-bold text-gray-900 text-lg leading-tight mb-1 line-clamp-2">{llibre.titol}</h3>
              <p className="text-sm text-gray-500 mb-3">{llibre.autor}</p>
              
              <div className="mt-auto pt-4 border-t border-gray-100 flex items-center justify-between">
                <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-lg">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  Disponible
                </span>
                <span className="text-xs font-medium text-gray-400 bg-gray-50 px-2 py-1 rounded-lg border border-gray-100">
                  {llibre.any_publicacio}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {filteredLlibres.length === 0 && (
        <div className="text-center py-20">
          <p className="text-gray-500 font-medium">No s'han trobat llibres amb aquesta cerca.</p>
        </div>
      )}
    </div>
  );
}

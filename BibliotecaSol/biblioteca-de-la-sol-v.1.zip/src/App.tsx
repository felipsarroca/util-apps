import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './lib/auth';
import Layout from './components/Layout';
import Login from './pages/Login';
import Catalog from './pages/Catalog';
import Editor from './pages/Editor';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
}

function AppRoutes() {
  const { user } = useAuth();
  
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={
          user ? <Catalog /> : <Navigate to="/login" replace />
        } />
        <Route path="login" element={
          user ? <Navigate to="/" replace /> : <Login />
        } />
        <Route path="editor" element={
          <ProtectedRoute>
            <Editor />
          </ProtectedRoute>
        } />
      </Route>
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}
